#pragma once

class CUtils
{
public:
	static GLuint LoadTexture(std::wstring const & fileName);
};
