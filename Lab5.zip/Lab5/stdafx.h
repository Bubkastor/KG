// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"		
#include <stdio.h>
#include <tchar.h>
#include <math.h>
#include <assert.h>
#include <string>
#include <stdexcept>
#include <stdlib.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <windows.h>
#include <GL/glut.h>
#include <gdiplus.h>





// TODO: reference additional headers your program requires here
